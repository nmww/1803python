#coding = utf-8
def test():
	print("send")
