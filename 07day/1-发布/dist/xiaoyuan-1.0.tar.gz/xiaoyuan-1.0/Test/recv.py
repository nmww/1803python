#coding=utf-8
def test1():
	print("recv哈哈哈")
